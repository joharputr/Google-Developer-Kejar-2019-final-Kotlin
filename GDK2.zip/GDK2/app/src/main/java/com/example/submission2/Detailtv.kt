package com.example.submission2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import com.example.submission2.movie.dataMovie
import kotlinx.android.synthetic.main.activity_detail.*

class Detailtv : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailtv)
        val data: dataMovie? = intent.getParcelableExtra("DATA")

        nama.text = data?.nama
        deskription.text = data?.deskripsi
        images.setImageResource(data!!.gambar)
        setSupportActionBar(toolbar1)

        val actionBar = supportActionBar

        actionBar!!.title = "Hello APP"

        actionBar.subtitle = "App subtitle"

        actionBar.elevation = 4.0F

        actionBar.setDisplayShowHomeEnabled(true)
        actionBar.setLogo(R.mipmap.ic_launcher)
        actionBar.setDisplayUseLogoEnabled(true)
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu to use in the action bar
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle presses on the action bar menu items
        when (item.itemId) {
            R.id.action_change_settings -> {
                val intent = Intent(Settings.ACTION_LOCALE_SETTINGS)
                startActivity(intent)
                return true
            }

        }
        return super.onOptionsItemSelected(item)
    }
}
