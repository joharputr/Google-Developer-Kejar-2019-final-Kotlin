package com.example.submission2.TVshow

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.submission2.R
import com.example.submission2.movie.dataMovie
import kotlinx.android.synthetic.main.movielist.view.*


class tvAdapter(
    val itemList: List<tvData>,
    private val onClick: (tvData) -> Unit
) : RecyclerView.Adapter<tvAdapter.movieHolder>() {

    class movieHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        fun bind(item: tvData) = itemView.apply {
            tv_item_name.text = item.nama
            tv_item_deskription.text = item.deskripsi
            img_item_photo.setImageResource(item.gambar)
        }
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): tvAdapter.movieHolder {
        val inflater = LayoutInflater.from(p0.context)
        val view = inflater.inflate(R.layout.tvlist, p0, false)
        return movieHolder(view)

    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(p0: tvAdapter.movieHolder, p1: Int) {
        val item = itemList[p1]
        p0.bind(item)
        p0.itemView.setOnClickListener {
            onClick(item)
        }
    }
}