package com.example.submission2.TVshow

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class tvData(
    val gambar: Int,
    val nama: String,
    val deskripsi: String?
) : Parcelable