package com.example.submission2.movie

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.submission2.Detail
import com.example.submission2.R
import kotlinx.android.synthetic.main.fragment_movies.*

class movieFragment : Fragment() {

    companion object {
        fun newInstance() = movieFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movies, container, false)
    }

    //memanggil resources string harus di dalam onViewCreated
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
      //  setupView()
        val test = context?.resources?.getString(R.string.deskripsi)
        val data = mutableListOf(
            dataMovie(
                R.drawable.poster_bumblebee,
                "Bumblebee",
                "" +context?.resources?.getString(R.string.bumblebee)
            ),
            dataMovie(
                R.drawable.poster_aquaman,
                "Aquaman",
                "" +context?.resources?.getString(R.string.aquaman)
                   ),
            dataMovie(
                R.drawable.poster_venom,
                "Venom",
                "" +context?.resources?.getString(R.string.venom)
            ),
            dataMovie(
                R.drawable.poster_avengerinfinity,
                "Avegner",
                "" +context?.resources?.getString(R.string.avenger)
            ),
            dataMovie(
                R.drawable.poster_robinhood,
                "RobinHood",
                "" +context?.resources?.getString(R.string.robinhood)
            ),
            dataMovie(
                R.drawable.poster_spiderman,
                "Spiderman",
                "" +context?.resources?.getString(R.string.spiderman)
            ),
            dataMovie(
                R.drawable.poster_dragonball,
                "DragonBAll",
                "" +context?.resources?.getString(R.string.dragonBall)
            ),
            dataMovie(
                R.drawable.poster_hunterkiller,
                "HunterKiller",
                "" +context?.resources?.getString(R.string.hunterkiller)
            ),
            dataMovie(
                R.drawable.poster_creed,
                "Creed",
                "" +context?.resources?.getString(R.string.creed)
            ),
            dataMovie(
                R.drawable.poster_deadpool,
                "Deadpool",
                "" +context?.resources?.getString(R.string.deadpool)
            )
        )
        val adapterMovie = movieAdapter(data, this::onCLick)
            movieRecyclerview.run {
                // layout baris kebawah
                layoutManager = LinearLayoutManager(context)
                adapter = adapterMovie
            }
    }

    private fun onCLick(dataMovie: dataMovie) {

        val intent = Intent(activity, Detail::class.java)
        intent.putExtra("DATA", dataMovie)
        startActivity(intent)

    }

}