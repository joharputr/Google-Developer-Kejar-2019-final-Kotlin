package com.example.submission2.movie

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.submission2.R
import kotlinx.android.synthetic.main.movielist.view.*


class movieAdapter(
    val itemList: List<dataMovie>,
    private val onClick: (dataMovie) -> Unit
) : RecyclerView.Adapter<movieAdapter.movieHolder>() {

    class movieHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        fun bind(item: dataMovie) = itemView.apply {
            tv_item_name.text = item.nama
            tv_item_deskription.text = item.deskripsi
            img_item_photo.setImageResource(item.gambar)
        }
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): movieAdapter.movieHolder {
        val inflater = LayoutInflater.from(p0.context)
        val view = inflater.inflate(R.layout.movielist, p0, false)
        return movieHolder(view)

    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(p0: movieAdapter.movieHolder, p1: Int) {
        val item = itemList[p1]
        p0.bind(item)
        p0.itemView.setOnClickListener {
            onClick(item)
        }
    }
}

